package com.aviva.camel;

import java.util.Arrays;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.model.dataformat.XmlJsonDataFormat;

public class ConvertXMLTOJSON {

	public static void main(String[] args) throws Exception {
		CamelContext camelContext = new DefaultCamelContext();
		try {
			camelContext.addRoutes(new RouteBuilder() {
				public void configure() {
					
					XmlJsonDataFormat xmlJsonFormat = new XmlJsonDataFormat();
					xmlJsonFormat.setEncoding("UTF-8");
					xmlJsonFormat.setForceTopLevelObject(true);
					xmlJsonFormat.setTrimSpaces(true);
					xmlJsonFormat.setRootName("newRoot");
					xmlJsonFormat.setSkipNamespaces(true);
					xmlJsonFormat.setRemoveNamespacePrefixes(true);
					xmlJsonFormat.setExpandableProperties(Arrays.asList("d", "e"));
					
					
					
					from("file:resources/inbox").marshal(xmlJsonFormat).to("file:resources/outbox");
					
					/*from("atom:file:src/main/resources/feed.atom?splitEntries=true&consumer.delay=1000")
							.to("seda:feeds");

					from("seda:feeds").filter().method(new CamelArticles(), "filter").to("seda:filteredArticles");

					from("seda:filteredArticles").to("stream:out");
*/				}
			});
			camelContext.start();
			Thread.sleep(5000);
		} finally {
			camelContext.stop();
		}
	}

}
